create view highest_rate_movies(movie_id, movie_name, movie_rating) as
SELECT movie_id,
       movie_name,
       movie_rating
FROM "MOVIES"
WHERE movie_rating > 8.0::double precision;

alter table highest_rate_movies
    owner to postgres;

