create function cleanup_user_dependencies() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Usunięcie powiązanych ulubionych filmów użytkownika
    DELETE FROM "FAVOURITE_MOVIES" WHERE user_id = OLD.user_id;
END;
$$;

alter function cleanup_user_dependencies() owner to postgres;

