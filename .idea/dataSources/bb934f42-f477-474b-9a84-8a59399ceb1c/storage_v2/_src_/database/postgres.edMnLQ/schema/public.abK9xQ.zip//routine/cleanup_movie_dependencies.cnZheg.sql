create function cleanup_movie_dependencies() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Usuwanie powiązanych ulubionych filmów
    DELETE FROM "FAVOURITE_MOVIES" WHERE movie_id = OLD.movie_id;
    -- Usuwanie powiązanych licencji filmu
    DELETE FROM "MOVIE_LICENSES" WHERE movie_id = OLD.movie_id;
    -- Usuwanie powiązań z aktorami, reżyserami i gatunkami
    DELETE FROM "MOVIE_ACTORS"   WHERE movie_id = OLD.movie_id;
    DELETE FROM "MOVIE_DIRECTORS" WHERE movie_id = OLD.movie_id;
    DELETE FROM "MOVIE_GENRES"   WHERE movie_id = OLD.movie_id;
    -- Usuwanie dodatkowych danych i lokalizacji (np. plakatu, języka, napisów)
    DELETE FROM "ADDITIONAL_MOVIE_DATA" WHERE movie_id = OLD.movie_id;
    DELETE FROM "MOVIE_LOCALIZATIONS"   WHERE movie_id = OLD.movie_id;
    RETURN OLD;
END;
$$;

alter function cleanup_movie_dependencies() owner to postgres;

