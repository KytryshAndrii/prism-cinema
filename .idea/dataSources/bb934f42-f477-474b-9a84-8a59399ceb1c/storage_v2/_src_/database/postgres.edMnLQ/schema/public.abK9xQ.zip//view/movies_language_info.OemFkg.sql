create view movies_language_info(movie_title, original_language, subtitles_language) as
SELECT m.movie_name       AS movie_title,
       amd.movie_language AS original_language,
       ml.subtitles_language
FROM "MOVIES" m
         JOIN "ADDITIONAL_MOVIE_DATA" amd ON amd.movie_id = m.movie_id
         JOIN "MOVIE_LOCALIZATIONS" ml ON ml.movie_id = amd.movie_id;

alter table movies_language_info
    owner to postgres;

