create function check_movie_has_director() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM "MOVIE_DIRECTORS" 
        WHERE movie_id = NEW.movie_id
    ) THEN
        RAISE EXCEPTION '[Error]: Movie "%" must have director!', NEW.movie_name;
    END IF;
    RETURN NULL;
END;
$$;

alter function check_movie_has_director() owner to postgres;

