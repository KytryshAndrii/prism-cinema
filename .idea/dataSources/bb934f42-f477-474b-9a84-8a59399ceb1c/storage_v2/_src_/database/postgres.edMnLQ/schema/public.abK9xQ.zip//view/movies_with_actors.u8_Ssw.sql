create view movies_with_actors(movie_title, actor) as
SELECT m.movie_name                                           AS movie_title,
       (a.first_name::text || ' '::text) || a.last_name::text AS actor
FROM "MOVIES" m
         JOIN "MOVIE_ACTORS" ma ON ma.movie_id = m.movie_id
         JOIN "ACTORS" a ON a.actor_id = ma.movie_id;

alter table movies_with_actors
    owner to postgres;

