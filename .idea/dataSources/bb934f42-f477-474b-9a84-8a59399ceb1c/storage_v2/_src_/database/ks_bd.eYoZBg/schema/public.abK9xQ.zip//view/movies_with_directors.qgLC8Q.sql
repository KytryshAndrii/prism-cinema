create view movies_with_directors(movie_title, directors) as
SELECT m.movie_name                                                                   AS movie_title,
       string_agg((d.first_name::text || ' '::text) || d.last_name::text, ', '::text) AS directors
FROM "MOVIES" m
         JOIN "MOVIE_DIRECTORS" md ON md.movie_id = m.movie_id
         JOIN "DIRECTORS" d ON d.director_id = md.director_id
GROUP BY m.movie_name;

alter table movies_with_directors
    owner to postgres;

