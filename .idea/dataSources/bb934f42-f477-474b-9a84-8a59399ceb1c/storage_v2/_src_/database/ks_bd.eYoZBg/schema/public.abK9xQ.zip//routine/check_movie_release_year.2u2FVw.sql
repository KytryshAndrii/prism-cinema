create function check_movie_release_year() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.movie_release_date > CURRENT_DATE THEN
        RAISE EXCEPTION '[Error]: Date is back to future. Not valid!';
    END IF;

    RETURN NEW;
END;
$$;

alter function check_movie_release_year() owner to postgres;

