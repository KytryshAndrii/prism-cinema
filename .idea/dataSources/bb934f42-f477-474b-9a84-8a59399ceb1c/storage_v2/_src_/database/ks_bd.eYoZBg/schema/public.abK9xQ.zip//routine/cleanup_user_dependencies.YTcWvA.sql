create function cleanup_user_dependencies() returns trigger
    language plpgsql
as
$$
BEGIN
  DELETE FROM "FAVOURITE_MOVIES" WHERE user_id = OLD.user_id;
    RETURN NULL;
END;
$$;

alter function cleanup_user_dependencies() owner to postgres;

