create view user_favourites_movies(user_, favourite_movie) as
SELECT u.user_login AS user_,
       m.movie_name AS favourite_movie
FROM "FAVOURITE_MOVIES" f
         JOIN "USERS" u ON u.user_id = f.user_id
         JOIN "MOVIES" m ON m.movie_id = f.movie_id;

alter table user_favourites_movies
    owner to postgres;

